public enum MowerStatus {
    TurnedOn, Stalled, Crashed, TurnedOff
}
