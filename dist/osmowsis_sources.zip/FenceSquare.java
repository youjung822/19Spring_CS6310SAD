public class FenceSquare extends Square {

    @Override
    protected String getName() {
        return "fence";
    }
}
