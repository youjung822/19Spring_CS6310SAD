public class CraterSquare extends Square {
    @Override
    protected String getName() {
        return "crater";
    }
}
